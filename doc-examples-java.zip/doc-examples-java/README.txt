Source code based on examples from Static Analysis documentation. 

src1 - Java source code containing defects
src2 - Java source code containing fixes to some defects